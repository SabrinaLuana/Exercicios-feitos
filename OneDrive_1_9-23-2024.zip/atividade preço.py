a = float(input("digite o preço do primeiro item: "))
b = float(input("digite o preço do segundo item: "))
c = float(input("digite o preço do terceiro item: "))

if a < b < c:
    print(f"o primeiro produto de {a} é o mais barato, compre ele.")
else:
    if a < c < b:
        print(f"o primeiro produto de {a} é o mais barato, compre ele.")
    else:
        if b < a < c:
            print(f"o segundo produto de {b} é o mais barato, compre ele.")
        else:
            if b < c < a:
                print(f"o segundo produto de {b} é o mais barato, compre ele.")
            else:
                if c < a < b:
                    print(f"o terceiro produto de {c} é o mais barato, compre ele.")
                else:
                    if c < b < a:
                        print(f"o terceiro produto de {c} é o mais barato, compre ele.")
                    else:
                        print("inválido")