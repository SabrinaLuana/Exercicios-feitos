a = str(input("digite um número menor que 1000: "))
centena = a[0:1]
dezena = a[1:2]
unidade = a[2:3]

if int(a) >= 100 and int(a) < 1000:
    centena = a[0:1]
    dezena = a[1:2]
    unidade = a[2:3]
    print(f"{centena} centenas, {dezena} dezenas, {unidade} unidades")
else:
    if int(a) >= 10 and int(a) < 99:
        dezena = a[0:1]
        unidade = a[1:2]
        print(f"{dezena} dezenas, {unidade} unidades")
    else:
        if int(a) >= 1 and int(a) <= 9:
            unidade = a[0:1]
            print(f"{unidade} unidades")
        else:
            print("inválido")